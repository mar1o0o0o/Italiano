IMPORTANTE: copiare il percorso del file tombolaTesto.txt, servirà per l'esecuzione del programma.

INDICAZIONI PER SCRIVERE LE CARTELLE

All'interno del file tombolaTesto.txt vanno scritte le cartelle che dovranno essere utilizzate durante la tombola.
Già sono presenti due cartelle di esempio.

Le cartelle devono essere inserite in questo modo:

NOME DEL GIOCATORE n.1
riga 1
riga 2
riga 3

NOME DEL. GIOCATORE n.2
riga 1
riga 2
riga 3

...

- I numeri devono essere scritti in notazione standard, senza parte decimale. Il primo numero non deve essere preceduto da uno spazio e l'ultimo numero non deve essere succeduto da uno spazio, tuttavia i numeri devono essere separati tra loro da uno spazio.
  Esempio:
  1 2 3 4 5

- Il nome del giocatore e ognuna delle tre righe devono essere contenute in una riga del
file.

- Non ci sono altre particolari limitazioni sul nome del giocatore.

- Le righe del file che contengono le informazioni per una cartella non devono essere separate da righe vuote.

- Le cartelle devono essere separate tra di loro da una ed una sola riga vuota.

- L'ultima cartella deve essere comunque succeduta da una riga vuota, mentre la prima cartella non deve essere preceduta da una riga vuota e deve invece occupare le prime 4 righe.

Seguire queste indicazioni è NECESSARIO per far funzionare il programma.
Grazie!

~MC

